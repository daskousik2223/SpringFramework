package pers.kd.udemy.spring.SpringTut1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringTut1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringTut1Application.class, args);
	}

}
