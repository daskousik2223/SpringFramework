package pers.kd.udemy.spring.SpringTut1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTut1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
